# LLM Prompt Examples for VSL

## Modify object properties
- "Move the red rectangle 50 pixels to the right."
- "Change the size of the rectangle to 150x150."

## Add new elements
- "Add a green circle with radius 30 in the top-left corner."

## Delete
- "Remove the rectangle from the scene."

## Style changes
- "Make the rectangle semi-transparent."
- "Add a black stroke around the rectangle."
